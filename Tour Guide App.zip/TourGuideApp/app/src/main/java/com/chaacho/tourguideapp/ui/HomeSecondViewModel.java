package com.chaacho.tourguideapp.ui;

import androidx.lifecycle.ViewModel;

public class HomeSecondViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
